//#include<iostream>
//void print(std::string message)
//{
//	std::cout << message << std::endl;
//}
//void print(int num)
//{
//	std::cout << num << std::endl;
//}
//
//int main()
//{
//	std::string months[] = { "January","February","March","April","May","June","July","August","September"
//					,"October","November","December"};
//
//	print("Months of the year:");
//	for (int i = 0; i < std::size(months); i++)
//	{
//		print(months[i]);
//	}
//	return 0;
//}