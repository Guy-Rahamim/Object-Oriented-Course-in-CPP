#include"Monkey.cpp";

int main()
{
	Monkey drew;

	char abeName[] = "abe";
	Monkey abe = Monkey("abe", 53, 100);

	char normanName[] = "norman";
	Monkey norman = Monkey(normanName, -314, 100);

	char dandelionName[] = "dandelion";
	Monkey dandelion = Monkey(dandelionName, 30, 510);

	char euclidName[] = "euclid";
	Monkey* euclid = new Monkey(euclidName,100,100);

	char harveyName[] = "harvey";
	Monkey* harvey = new Monkey(harveyName, 93, 35);

	harvey->setName("JOE");
	euclid->setWeight(55);
	drew.setAge(12);

	Monkey monkeyArray[] = { drew, abe, norman, dandelion , * euclid, * harvey};

	//printing the values for each monkey.
	for (int i = 0; i < 6; i++)
	{	
		std::cout << "Monkey number : " << i<< "\t";
		monkeyArray[i].print(); 
	}
	
	//feeding drew 20 times. poor drew.
	char foodForDrew[] = "banana";
	for (int i = 0; i < 20; i++)
	{
		monkeyArray[0].eat(foodForDrew);
	}
	std::cout << monkeyArray[0].getName() << "'s weight is now: " << monkeyArray[0].getWeight() << std::endl;

	for (int i = 0; i < 15; i++)
	{
		monkeyArray[1].poop();
	}
	std::cout << monkeyArray[1].getName() << "'s weight is now: " << monkeyArray[1].getWeight() << std::endl;


	delete euclid;
	delete harvey;
	return 0;
}