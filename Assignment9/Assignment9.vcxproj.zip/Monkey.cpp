#include<iostream>

class Monkey
{
//void setName(char* newName);
//void setWeight(int newWeight);
//void setAge(int newAge);
public :
	
	Monkey() //default constructor
	{
		char str[] = "noname";
		setName(str);
		weight = 0;
		age = 0;
	}

	 Monkey(const char* newName, int newAge, int newWeight) //parametric constructor
	 {
		 setName(newName);
		 setAge(newAge);
		 setWeight(newWeight);
	 }

	 Monkey(const Monkey& monkey)
	 {
		 this->name = NULL;
		 setName(monkey.name);
		 setAge(monkey.age);
		 setWeight(monkey.weight);
	 }

	 ~Monkey()
	 {	 delete[] name;	 	}

	char* getName()
	{	return name;	}
	
	int getAge()
	{	return age;		}

	int getWeight()
	{	return weight;	}

	void setName(const char* newName)
	{
		char defaultName[] = "kofiko";

		//deleting the the value name is pointing to.
		delete (this->name);

		//storing the length of the new name.
		int nameLength = strlen(newName)+1;

		//dynamically allocating a memory block with the new name's length.
		name = new char[nameLength+1 ];

		//if there are no digits in the new name, copy it to the name field
		if (checkForDigits(newName))
		{
			strcpy_s(name, nameLength, newName);
		}

		else
		{
			std::cout << "ERROR: name" << std::endl;
			this->name = defaultName;
		}

	}

	bool checkForDigits(const char* newName)
	{
		for (int i = 0; i < strlen(newName); i++)
		{
			if (*(newName+i)<=9 && *(newName+i)>=0)
				return false;
		}
		return true;
	}

	void setAge(int newAge)
	{
		if (newAge < 0 || newAge>100)
		{
			std::cout << "ERROR:  age"<<std::endl;
			age = 40;
		}
		else
			age = newAge;
	}

	void setWeight(int newWeight)
	{
		if (newWeight < 3 || newWeight>200)
		{
			std::cout << "ERROR: Weight at Monkey " <<this->getName()<<std::endl;
			weight = 100;
		}
		else
			weight = newWeight;
	}

	void print()
	{	std::cout << "Name: " << name << "\tAge: " << getAge() << "\tWeight: " << getWeight() << std::endl;	}

	void eat(char* food)
	{
		setWeight(getWeight() + 10);
		std::cout << getName() << " eats " << food << std::endl;
	}

	void poop()
	{
		setWeight(getWeight() - 15);
	}
private:
	char* name;
	int age;
	int weight;
	

};
